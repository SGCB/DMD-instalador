var headerHeight = 0;
var footerHeight = 0;

function UpdateTableHeaders() {
	var pTable = 0;
	$("table.tableWithFloatingHeader").each(function() {
		var elem = $(this);
		offsetT = elem.offset();
		heightT = elem.height();
		widthT = elem.width()-1;
		scrollTop = $(window).scrollTop();
		$("tr.floatingHeaders",elem).each(function() {
			   var elemTR = $(this);
			if ((scrollTop > offsetT.top+elemTR.height()-headerHeight) && ((scrollTop+headerHeight) < offsetT.top + heightT )) {
			   elemTR.css("top", (scrollTop+headerHeight+1) + "px");
			   elemTR.css("left", (offsetT.left+1)+"px");
			   if (elemTR.width() != widthT) {
					elemTR.css("width", widthT + "px");
				}
			   var pCol = 0;
			   $("th",elemTR).each(function() {
					var elemTD = $(this);
					var widthRef = basisElem[pTable][pCol].width();
					if (elemTD.width() != widthRef) {
						elemTD.css("width",  widthRef + "px");
					}
					pCol++;
			   });
			   elemTR.show();
			}
			else {
				elemTR.hide();
			}
		});
		 pTable++;
	});
}

var basisElem;

$(document).ready(function() {
    skosBasketUpdateSize();

	var pTable = 0;
	basisElem = [];
	$("table.tableWithFloatingHeader").each(function() {
		 var thisTable = $(this);
		 basisElem[pTable] = [];
		 $("tr.floatingHeaders",thisTable).each(function() {
			var elem = $(this);
			elem.hide();
			elem.css("position", "absolute");
		 });
		 $("tr.SkosTableSecondRow",thisTable).each(function() {
			var row2 = $(this);
			var pCol = 0;
			$("th",row2).each(function(){
				basisElem[pTable][pCol] = $(this);
				pCol++;
			});
		 });
		 pTable++;
	});
	UpdateTableHeaders();
	$(window).scroll(UpdateTableHeaders);
});

// The SKOS Basket !
	function skosBasketList(theElement,suffix) {
		if (skosBasketSize()==0) {
			return false;
		} else {
			theElement.href = sessvars.contextPath+"/search.jsp?basket="+sessvars.skosBasket.substring(1)+suffix;
		}
		return true;
	}
	
	function skosBasketLoad(handleNum,imagePrefix) {
		if (imagePrefix == null || typeof(imagePrefix)=='undefined') {
			imagePrefix = "skosBasket";
		}
	    var currImg = document.images[imagePrefix+handleNum];
		if (typeof(sessvars.skosBasket)=='undefined') {
		  sessvars.skosBasket = ",";
  		  currImg.src=sessvars.contextPath+"/image/outbasket.gif";
		}
		else if (sessvars.skosBasket.indexOf(","+handleNum+",") >= 0) {
			currImg.src=sessvars.contextPath+"/image/inbasket.gif";
		} else {
			currImg.src=sessvars.contextPath+"/image/outbasket.gif";
		}
	}

	function skosBasketSize() {
		if (typeof(sessvars.skosBasket)!='undefined') {
		  var j=0;
		  for (i=1;i<sessvars.skosBasket.length;i++) {
		      if (sessvars.skosBasket.charAt(i)==',') {
				j++;
			  }
		  }
		  return j;
		}
		return 0;
	}
	
	function skosBasketClipboard(delim) {
		if (skosBasketSize()==0) {
			return false;
		} else {
			var clipping = sessvars.skosBasket.substring(1,sessvars.skosBasket.length-1).replace(/,/g,delim);
			if ($.browser.mozilla) {
				try
				{
				    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
				}
				catch (e)
				{
					alert("Please configure your browser to make Clipboard accessible using JavaScript.\nThis page may help you: http://www.febooti.com/support/website-help/website-javascript-copy-clipboard.html");
					return false;
				}
 				var gClipboardHelper =
					Components.classes["@mozilla.org/widget/clipboardhelper;1"]
						.getService(Components.interfaces.nsIClipboardHelper);
				// Copie du texte dans le presse papier.
				gClipboardHelper.copyString(clipping);
			} else {
				window.clipboardData.setData('Text', clipping);
			}
			var theElement = document.getElementById("imgSkosBasketClipboard");
			if (theElement!==null && typeof(theElement)!='undefined') {
				theElement.src=sessvars.contextPath+"/image/clipdone.gif";
			}
		}
		return true;
	}  
	
	function skosBasketUpdateSize() {
		var aSize = skosBasketSize();
		var theElement = document.getElementById("skosBasketSize");
		if (theElement!==null && typeof(theElement)!='undefined') {
			if (aSize == 0) {
			  theElement.innerHTML = "";
			} else {
			  theElement.innerHTML = ""+aSize;
			}
		}
		theElement = document.getElementById("skosBasketDel");
		if (theElement!==null && typeof(theElement)!='undefined') {
			if (aSize == 0) {
			  theElement.style.display = "none";
			} else {
			  theElement.style.display = "";
			}
		}
		theElement = document.getElementById("imgSkosBasketList");
		if (theElement!==null && typeof(theElement)!='undefined') {
			if (aSize == 0) {
			  theElement.style.display = "none";
			} else {
			  theElement.style.display = "";
			}
		}
		theElement = document.getElementById("imgSkosBasketClipboard");
		if (theElement!==null && typeof(theElement)!='undefined') {
			if (aSize == 0) {
			  theElement.style.display = "none";
			} else {
			  theElement.style.display = "";
			  theElement.src=sessvars.contextPath+"/image/clipempty.gif";
			}
		}
		theElement = document.getElementById("skosBasketLinkOut");
		if (theElement!==null && typeof(theElement)!='undefined') {
			if (aSize == 0) {
			  theElement.style.display = "none";
			} else {
			  theElement.style.display = "";
			}
		}
	}

	function skosBasketToggle(handleNum, imagePrefix) {
		if (imagePrefix == null || typeof(imagePrefix)=='undefined') {
			imagePrefix = "skosBasket";
		}
	    var anElement = document.images[imagePrefix+handleNum];
		if (typeof(sessvars.skosBasket)=='undefined') {
			if (anElement !== null && typeof(anElement)!='undefined') {
			   anElement.src=sessvars.contextPath+"/image/inbasket.gif";
			}
			sessvars.skosBasket = ","+sessvars.skosBasket+handleNum+",";
		}
		else {
			pos = sessvars.skosBasket.indexOf(","+handleNum+",");
			if (pos >= 0) {
				sessvars.skosBasket = sessvars.skosBasket.substring(0,pos)+sessvars.skosBasket.substring(pos+handleNum.length+1,sessvars.skosBasket.length);
				if (anElement !== null && typeof(anElement)!='undefined') {
				   anElement.src=sessvars.contextPath+"/image/outbasket.gif";
				}
			} else {
				if (anElement !== null && typeof(anElement)!='undefined') {
				   anElement.src=sessvars.contextPath+"/image/inbasket.gif";
				}
				sessvars.skosBasket = sessvars.skosBasket+handleNum+",";
			}
		}
		skosBasketUpdateSize(handleNum);
		if (imagePrefix != "skosBasket") {
			skosBasketLoad(handleNum,"skosBasket");
		}
		if (imagePrefix != "topSkosBasket" && document.images["topSkosBasket"+handleNum] != null) {
			skosBasketLoad(handleNum,"topSkosBasket");
		}
	}
	
	function skosBasketClear() {
		var aSize = skosBasketSize();
		if (aSize > 0) {
			if (confirm(aSize+" concept"+(aSize > 1?"s":"")+". Clear Print Basket ?")) {
				var origBasket = sessvars.skosBasket;
				for (i = 0;
    				 i>=0;
					 i = origBasket.indexOf(",")) {
				    oneEntry = origBasket.substring(0,i);
					origBasket = origBasket.substring(i+1,62500);
					if (oneEntry.length > 0) {
					  skosBasketToggle(oneEntry);
					}
				}
				sessvars.skosBasket = ",";
				skosBasketUpdateSize();
			}
		}
	}
	
	function skosBasketLinkOut(theElement,boolOp) {
		if (skosBasketSize()==0) {
			return false;
		} else {
			theElement.href = "http://eprints.rclis.org/simple-search?query="+sessvars.skosBasket.substring(1,sessvars.skosBasket.length-1).replace(/,/g,boolOp).replace(/jita\_/g,'');
		}
		return true;
	}
